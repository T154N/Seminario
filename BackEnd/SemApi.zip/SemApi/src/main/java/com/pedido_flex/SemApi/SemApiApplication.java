package com.pedido_flex.SemApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SemApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SemApiApplication.class, args);
	}

}
