package com.pedido_flex.wsPedidoFlex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WsPedidoFlexApplication {

	public static void main(String[] args) {
		SpringApplication.run(WsPedidoFlexApplication.class, args);
	}

}
