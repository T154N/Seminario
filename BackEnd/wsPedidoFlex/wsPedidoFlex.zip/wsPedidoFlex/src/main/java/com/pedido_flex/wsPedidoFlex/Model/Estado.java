package com.pedido_flex.wsPedidoFlex.Model;

public class Estado {
}
