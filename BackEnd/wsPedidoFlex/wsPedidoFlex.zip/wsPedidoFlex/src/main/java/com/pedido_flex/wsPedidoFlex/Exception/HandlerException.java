package com.pedido_flex.wsPedidoFlex.Exception;

public class HandlerException extends Exception{
    public HandlerException(String message){
        super(message);
    }
}
