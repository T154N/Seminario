package com.pedido_flex.wsPedidoFlex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsPedidoFlexApplicationTests {

	@Test
	void contextLoads() {
	}

}
