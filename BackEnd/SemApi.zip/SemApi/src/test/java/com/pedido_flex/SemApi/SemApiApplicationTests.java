package com.pedido_flex.SemApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SemApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
